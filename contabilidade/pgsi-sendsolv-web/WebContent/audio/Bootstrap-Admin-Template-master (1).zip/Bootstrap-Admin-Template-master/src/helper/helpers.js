var foo = function(msg) {
  return '<!-- ' + msg + ' -->';
};

module.exports.foo = foo;
